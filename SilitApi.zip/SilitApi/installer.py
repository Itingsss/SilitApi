# chmod 777
# sudo python3 installer.py
import os, time, sys

os.system('clear')
os.system('apt install screen python3 python3-pip')
time.sleep(1)
os.system('python3 -m pip -r requirements.txt')
time.sleep(1)
os.system('clear')
time.sleep(5)
sys.exit()